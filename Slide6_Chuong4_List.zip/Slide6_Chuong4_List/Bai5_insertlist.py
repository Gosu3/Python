my_list = ['zero', 'three']


my_list.insert(1,'one')
my_list.insert(2, 'two')

print(my_list)