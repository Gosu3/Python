my_list = [11, 2, 23, 45, 6, 9]

print ("Số lớn nhất trong list là: ", max(my_list))        