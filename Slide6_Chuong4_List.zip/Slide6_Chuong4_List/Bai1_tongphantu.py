numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]

tong = 0
for num in numbers:
    tong+=num
print("Tổng các phần tử trong danh sách là: ", tong)