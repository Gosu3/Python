numbers = [1, 2, 3, 4, 5]

tich = 1
for num in numbers:
    tich*=num
print("Tổng các phần tử trong danh sách là: ", tich)
