# Cách 1
original_list = [1, 2, 3, 4, 5]

new_list = original_list[:]


print("Danh sách mới:", new_list)

#Cách 2

original_list = [1, 2, 3, 4, 5]


new_list = original_list.copy()

print("Danh sách mới:", new_list)
