my_list = [11, 2, 23, 45, 6, 9]

print ("Số nhỏ nhất trong list là: ", min(my_list))  