color_list = ['Red', 'Green', 'White', 'Black', 'Pink', 'Yellow']

new_list = color_list[2:4]
print(new_list)